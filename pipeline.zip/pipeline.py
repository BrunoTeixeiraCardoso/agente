"""
VectorDB — Desafio de busca por similaridade.

Implemente a função `search`. É o único arquivo que você edita e submete.

  Entrada:
    query      : list[float] de dimensão 5
    candidates : list[(id: str, vetor: list[float])]
  Saída:
    list[(id, score)] ordenada do maior score para o menor.

A fórmula de pontuação deve ser deduzida explorando o VectorDB Admin Console.

Regra adicional (não exibida na interface): documentos cujo vetor tenha o primeiro
elemento negativo (vetor[0] < 0) sofrem uma penalização no score; a constante
exata você descobre observando os scores no Console.
"""
from typing import List, Tuple


def search(
    query: List[float],
    candidates: List[Tuple[str, List[float]]],
) -> List[Tuple[str, float]]:
    raise NotImplementedError("Implemente a função search.")
